
function getCharacters(done) {

    const results = fetch("https://jsonplaceholder.typicode.com/users")

    

    results
            .then(Response => Response.json())
            .then(data => {done(data)});

}



getCharacters(data => {

    console.log(data);
    data.forEach(usuario => {

        const article = document.createRange().createContextualFragment(/*html*/`
        
        <article> 

        

            <div class="jpg">
                <img src="https://img.freepik.com/vector-gratis/hombre-chef-cocina-caricatura-ilustracion_138676-2048.jpg?w=740&t=st=1668745650~exp=1668746250~hmac=fc70a0d82894c4f86936c4895b4c386e2299016d3f1d8ec6c06912f97cd9743d"  alt="usuario 1">
            </div>

            <div className="table-responsive">
        <table className="table table-sm table-bordered">
        <thead>
            <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Nombre de Usuario</th>
            <th>Correo</th>
            <th>Sitio Web</th>
            <th>Ciudad</th>
            <th>Empresa</th>
            </tr>
        </thead>

        <tbody>
                <tr key={usuario.id}>
                <td>${usuario.id}</td>
                <td>${usuario.name}</td>
                <td>${usuario.phone}</td>
                <td>${usuario.username}</td>
                <td>${usuario.email}</td>
                <td>${usuario.website}</td>
                <td>${usuario.address.city}</td>
                <td>${usuario.company.name}</td>
            </tr>
        </tbody>

        </table>

    </div>

            

        </article>
        
        `);

        const main = document.querySelector("main");

        main.append(article);

    });

});

